import { createFileRoute } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { meta, weekly } from "@/lib/club";
import { PageHero, CtaBand } from "@/components/site";

export const Route = createFileRoute("/horaires")({
  head: () => meta("Horaires", "Planning hebdomadaire des entraînements du club L'ESPADON à Fort-de-France et au Lamentin."),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero eyebrow="Planning de la semaine" title="Horaires des entraînements">
        Sauf mention, les séances ont lieu à la piscine du lycée Joseph Gaillard, Fort-de-France.
      </PageHero>
      <section className="mx-auto mt-14 grid max-w-6xl gap-4 px-4 sm:grid-cols-2 lg:grid-cols-5">
        {weekly.map((d) => (
          <div key={d.day} className="rounded-3xl border border-border bg-card p-5">
            <h2 className="text-lg font-bold text-primary">{d.day}</h2>
            <ul className="mt-4 space-y-3">
              {d.slots.map((s) => (
                <li key={s.time + s.label} className="rounded-xl bg-muted p-3">
                  <p className="font-display text-sm font-bold">{s.time}</p>
                  <p className="text-sm">{s.label}</p>
                  {s.place && <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3 w-3" />{s.place}</p>}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>
      <p className="mx-auto mt-6 max-w-6xl px-4 text-sm text-muted-foreground">Lamentin : Centre aquatique communautaire Pierre Samot.</p>
      <CtaBand />
    </>
  );
}
