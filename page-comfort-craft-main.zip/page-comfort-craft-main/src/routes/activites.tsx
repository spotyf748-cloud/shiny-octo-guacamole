import { createFileRoute, Link } from "@tanstack/react-router";
import { Baby, Trophy, Waves, Check } from "lucide-react";
import { meta } from "@/lib/club";
import { PageHero, CtaBand } from "@/components/site";

export const Route = createFileRoute("/activites")({
  head: () => meta("Nos activités", "École de natation dès 3 ans, compétition jeunes et Maîtres, loisirs et aquagym au club L'ESPADON."),
  component: Page,
});

const items = [
  { icon: Baby, title: "École de natation", age: "Dès 3 ans", when: "Samedi après-midi", points: ["Découverte ludique de l'eau", "Petits groupes par âge et niveau", "Séances de 45 min"] },
  { icon: Trophy, title: "Compétition", age: "Jeunes & adultes", when: "Le soir dès 17h30", points: ["Pré-compétition Marlin", "Compétitions FFN régionales à internationales", "Section Maîtres dès 25 ans"] },
  { icon: Waves, title: "Loisirs / Bien-être", age: "Jeunes & adultes", when: "Samedi midi & soirs", points: ["Aquagym", "Natation adultes débutants", "Nage avec palmes"] },
];

function Page() {
  return (
    <>
      <PageHero eyebrow="Nos activités" title="Une formule pour chaque nageur">
        Des cours adaptés à tous les niveaux, encadrés par des coachs qualifiés, dans une ambiance conviviale.
      </PageHero>
      <section className="mx-auto mt-14 grid max-w-6xl gap-6 px-4 md:grid-cols-3">
        {items.map((i) => (
          <article key={i.title} className="flex flex-col rounded-3xl border border-border bg-card p-7">
            <i.icon className="h-9 w-9 text-primary" />
            <h2 className="mt-4 text-2xl font-bold">{i.title}</h2>
            <p className="mt-1 text-sm font-medium text-muted-foreground">{i.age} · {i.when}</p>
            <ul className="mt-5 flex-1 space-y-2">
              {i.points.map((p) => <li key={p} className="flex gap-2"><Check className="mt-0.5 h-5 w-5 shrink-0 text-accent" />{p}</li>)}
            </ul>
            <Link to="/inscriptions" className="mt-6 rounded-full bg-secondary py-3 text-center font-semibold text-secondary-foreground hover:brightness-95">Tarifs & inscription</Link>
          </article>
        ))}
      </section>
      <CtaBand />
    </>
  );
}
