import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X, Facebook, Instagram, MapPin, ArrowRight } from "lucide-react";
import { club, nav } from "@/lib/club";
import logoAsset from "@/assets/logo.png.asset.json";

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold text-primary" onClick={() => setOpen(false)}>
          <img src={logoAsset.url} alt="Logo de L'ESPADON" className="h-10 w-10 shrink-0 object-contain" />
          L'ESPADON
        </Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Navigation principale">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition hover:bg-secondary hover:text-foreground" activeProps={{ className: "bg-secondary text-foreground" }}>
              {n.label}
            </Link>
          ))}
          <Link to="/dons" className="ml-2 rounded-full bg-sun px-4 py-2 text-sm font-semibold text-sun-foreground transition hover:brightness-95">
            Faire un don
          </Link>
        </nav>
        <button className="rounded-full p-2 lg:hidden" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="border-t border-border bg-background px-4 pb-4 lg:hidden">
          {[...nav, { to: "/dons", label: "Faire un don" } as const].map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="block rounded-xl px-3 py-3 text-base font-medium" activeProps={{ className: "bg-secondary" }}>
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 bg-deep text-deep-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <p className="font-display text-2xl font-bold">L'ESPADON</p>
          <p className="mt-1 opacity-75">Cercle de Nageurs de Fort-de-France · depuis 1969</p>
          <p className="mt-4 flex gap-2 text-sm opacity-75"><MapPin className="h-4 w-4 shrink-0" />{club.address}</p>
          <div className="mt-5 flex gap-3">
            <a href={club.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="rounded-full bg-deep-foreground/10 p-2.5 hover:bg-deep-foreground/20"><Facebook className="h-5 w-5" /></a>
            <a href={club.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="rounded-full bg-deep-foreground/10 p-2.5 hover:bg-deep-foreground/20"><Instagram className="h-5 w-5" /></a>
          </div>
        </div>
        <div className="space-y-2 text-sm">
          <p className="font-semibold">Pratique</p>
          <Link to="/inscriptions" className="block opacity-75 hover:opacity-100">Inscriptions & tarifs</Link>
          <Link to="/horaires" className="block opacity-75 hover:opacity-100">Horaires</Link>
          <Link to="/documents" className="block opacity-75 hover:opacity-100">Documents</Link>
          <a href={club.login} className="block opacity-75 hover:opacity-100">Espace adhérent</a>
        </div>
        <div className="space-y-2 text-sm">
          <p className="font-semibold">Le club</p>
          <Link to="/club" className="block opacity-75 hover:opacity-100">Histoire & comité</Link>
          <Link to="/partenaires" className="block opacity-75 hover:opacity-100">Partenaires</Link>
          <a href={club.legal} className="block opacity-75 hover:opacity-100">Mentions légales</a>
          <a href={club.tos} className="block opacity-75 hover:opacity-100">CGU / CGV</a>
        </div>
      </div>
    </footer>
  );
}

export function PageHero({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <section className="bg-ocean text-primary-foreground">
      <div className="mx-auto max-w-6xl px-4 py-16 md:py-20">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-4xl font-bold md:text-5xl">{title}</h1>
        {children && <div className="mt-4 max-w-2xl text-lg opacity-85">{children}</div>}
      </div>
    </section>
  );
}

export function CtaBand() {
  return (
    <section className="mx-auto mt-20 max-w-6xl px-4">
      <div className="flex flex-col items-start justify-between gap-6 rounded-3xl bg-secondary p-8 md:flex-row md:items-center md:p-10">
        <div>
          <h2 className="text-2xl font-bold md:text-3xl">Prêt à plonger ?</h2>
          <p className="mt-1 text-muted-foreground">Choisissez votre formule et inscrivez-vous en ligne en quelques minutes.</p>
        </div>
        <Link to="/inscriptions" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-soft transition hover:translate-x-0.5">
          Voir les formules <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </section>
  );
}
