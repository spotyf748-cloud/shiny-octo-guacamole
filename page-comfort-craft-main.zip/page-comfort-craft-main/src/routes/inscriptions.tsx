import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Clock, ArrowRight, FileText } from "lucide-react";
import { formulas, meta, slugify, type Formula } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/inscriptions")({
  head: () => meta("Inscriptions & tarifs", "Toutes les formules et tarifs du club L'ESPADON : école de natation, compétition, loisirs, étudiants et licences."),
  component: Page,
});

const filters = ["Tous", "Enfants", "Adultes", "Compétition", "Club"] as const;

function Page() {
  const [f, setF] = useState<(typeof filters)[number]>("Tous");
  const list = f === "Tous" ? formulas : formulas.filter((x) => x.audience === f);
  return (
    <>
      <PageHero eyebrow="Saison 2026–2027" title="Inscriptions & tarifs">
        Filtrez par public, comparez les créneaux et inscrivez-vous en ligne.
      </PageHero>
      <div className="mx-auto max-w-6xl px-4">
        <div className="sticky top-16 z-10 -mx-4 flex gap-2 overflow-x-auto bg-background/90 px-4 py-4 backdrop-blur" role="tablist">
          {filters.map((x) => (
            <button key={x} role="tab" aria-selected={f === x} onClick={() => setF(x)}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${f === x ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:brightness-95"}`}>
              {x}
            </button>
          ))}
        </div>
        <Link to="/documents" className="mb-6 flex items-center gap-3 rounded-2xl border border-dashed border-primary/40 p-4 text-sm">
          <FileText className="h-5 w-5 text-primary" /> Pensez à préparer la licence et le questionnaire de santé.
          <span className="ml-auto font-semibold text-primary">Documents →</span>
        </Link>
        <div className="grid gap-6 md:grid-cols-2">
          {list.map((x) => <Card key={x.name} f={x} />)}
        </div>
      </div>
    </>
  );
}

function Card({ f }: { f: Formula }) {
  const main = f.offers?.[0];
  return (
    <article className="flex flex-col rounded-3xl border border-border bg-card p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground">{f.audience}</span>
          <h2 className="mt-3 text-xl font-bold">{f.name}</h2>
        </div>
        <p className="shrink-0 text-right font-display text-2xl font-bold text-primary">{main ? main.price : "Sur demande"}</p>
      </div>
      <p className="mt-3 text-muted-foreground">{f.description}</p>
      {f.schedule && (
        <ul className="mt-4 space-y-1.5 text-sm">
          {f.schedule.map((s) => <li key={s} className="flex gap-2"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-accent" />{s}</li>)}
        </ul>
      )}
      {f.offers && f.offers.length > 1 && (
        <dl className="mt-4 divide-y divide-border rounded-2xl bg-muted px-4 text-sm">
          {f.offers.map((o) => <div key={o.name} className="flex justify-between py-2"><dt>{o.name}</dt><dd className="font-semibold">{o.price}</dd></div>)}
        </dl>
      )}
      <div className="mt-auto flex items-center justify-between gap-4 pt-6">
        <span className="text-xs text-muted-foreground">Ouverture : {f.opening}</span>
        <Link to="/inscriptions/$slug" params={{ slug: slugify(f.name) }} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:brightness-110">
          Détails & inscription <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </article>
  );
}
