import historyImg from "@/assets/history.png.asset.json";
import committeeImg from "@/assets/committee.jpg.asset.json";
import dreamImg from "@/assets/dream.png.asset.json";

export const SITE = "https://www.espadon-fortdefrance.fr";

export const club = {
  name: "L'ESPADON",
  fullName: "L'ESPADON Cercle de Nageurs de Fort-de-France",
  slogan: "L'instant bleu qui nous rassemble",
  address: "Bâtiment Alizé 4 RDC, Cité de Briand, Floréal, 97234 Fort-de-France",
  facebook: "https://www.facebook.com/espadoncnfortdefrance/",
  instagram: "https://instagram.com/cn_espadonfdf",
  login: `${SITE}/contacts/login`,
  contactForm: `${SITE}/page/3833173-contact`,
  donate: `${SITE}/page/4147617-faire-un-don`,
  legal: `${SITE}/infos/legal-notice`,
  tos: `${SITE}/infos/tos`,
};

export const nav = [
  { to: "/activites", label: "Activités" },
  { to: "/horaires", label: "Horaires" },
  { to: "/inscriptions", label: "Inscriptions" },
  { to: "/evenements", label: "Évènements" },
  { to: "/club", label: "Le club" },
  { to: "/contact", label: "Contact" },
] as const;

export type Offer = { name: string; price: string };
export type Formula = {
  slug?: string;
  name: string;
  audience: "Enfants" | "Adultes" | "Compétition" | "Club";
  url: string;
  description: string;
  schedule?: string[];
  offers?: Offer[];
  opening: string;
};

const c = (s: string) => `${SITE}/collect/description/${s}`;

export const formulas: Formula[] = [
  {
    name: "École de natation (3–4 ans)", audience: "Enfants", url: c("711029-j-ecole-de-natation-3-4-ans"),
    description: "Groupe Blanc : découverte ludique et sécurisée de l'eau, séances de 45 min en petits groupes. Début : premier samedi d'octobre.",
    schedule: ["BLANC 1 : samedi 15h00", "BLANC 2 : samedi 15h45"],
    offers: [{ name: "Blanc 1 ou Blanc 2", price: "300 €" }, { name: "Frais nouvel adhérent", price: "20 €" }],
    opening: "1 juin 2026",
  },
  {
    name: "École de natation (4–7 ans)", audience: "Enfants", url: c("715332-j-ecole-de-natation-4-7-ans"),
    description: "Apprentissage progressif et structuré, groupes selon le niveau et l'âge. Début : premier samedi d'octobre.",
    schedule: ["JAUNE 1 : samedi 15h15 (4–5 ans)", "JAUNE 2 : samedi 16h00 (4–5 ans)", "BLEU 1 : samedi 14h30 (5–6 ans)", "BLEU 2 : samedi 16h45 (5–6 ans)", "VIOLET : samedi 16h45 (6–7 ans)"],
    offers: [{ name: "Jaune / Bleu / Violet", price: "350 €" }, { name: "Frais nouvel adhérent", price: "20 €" }],
    opening: "1 juin 2026",
  },
  {
    name: "Pré-compétition", audience: "Compétition", url: c("700506-c-pre-competition"),
    description: "Transition entre apprentissage et compétition : technique, endurance et condition physique.",
    schedule: ["MARLIN 1 : mardi et jeudi 17h30–18h30", "MARLIN 2 : mardi 17h30–18h30, jeudi 18h30–19h30"],
    opening: "1 juin 2026",
  },
  {
    name: "Compétition", audience: "Compétition", url: c("700496-c-competition"),
    description: "Entraînement structuré et compétitions FFN/FINA régionales, nationales et internationales. Tarif sur demande.",
    opening: "1 juin 2026",
  },
  {
    name: "Compétition Maîtres (25 ans +)", audience: "Compétition", url: c("715333-j-competition-maitres"),
    description: "Section réservée aux nageurs compétiteurs à partir de 25 ans, règles FFN et FINA.",
    schedule: ["Mardi 12h–13h, Centre aquatique Pierre Samot (Lamentin)", "Mercredi 19h30–20h30, lycée Joseph Gaillard", "Jeudi 19h30–20h30, lycée Joseph Gaillard", "Vendredi 12h–13h, Centre aquatique Pierre Samot (Lamentin)"],
    offers: [{ name: "Maîtres", price: "350 €" }, { name: "Frais nouvel adhérent", price: "20 €" }],
    opening: "1 juin 2026",
  },
  {
    name: "Loisirs / Bien-être", audience: "Adultes", url: c("716265-j-loisirs-bien-etre"),
    description: "Sans objectif de compétition, pour enfants et adultes : natation, perfectionnement et aquagym.",
    schedule: ["Aquagym : samedi 12h–13h", "Adultes débutants : samedi 13h–14h", "Nage avec palmes : jeudi 19h30–20h30", "Loisirs : mardi 18h30–19h30 et samedi 14h30–15h30"],
    offers: [
      { name: "1 cours / semaine", price: "280 €" },
      { name: "Pack Duo (2 cours)", price: "320 €" },
      { name: "Pack complet (3 cours)", price: "350 €" },
      { name: "Frais nouvel adhérent", price: "20 €" },
    ],
    opening: "1 juin 2026",
  },
  {
    name: "Étudiant", audience: "Adultes", url: c("700848-t-etudiant"),
    description: "Allier sport et études avec des horaires adaptés.",
    schedule: ["Mardi 19h30–20h30, lycée Joseph Gaillard", "Jeudi 19h30–20h30, lycée Joseph Gaillard"],
    offers: [{ name: "Adhésion étudiant", price: "220 €" }, { name: "Frais nouvel adhérent", price: "20 €" }],
    opening: "1 juin 2026",
  },
  {
    name: "Licence plurielle", audience: "Club", url: c("698957-j-licences-plurielles"),
    description: "Pour participer aux compétitions sous les couleurs de L'ESPADON et représenter le club.",
    offers: [{ name: "Licence plurielle", price: "80 €" }],
    opening: "15 mai 2026",
  },
  {
    name: "Bénévoles", audience: "Club", url: c("698969-j-benevoles"),
    description: "Participez à la vie du club, aux compétitions et manifestations ; formation possible comme officiel FFN.",
    offers: [{ name: "Licence simple", price: "20 €" }],
    opening: "15 mai 2026",
  },
];

export const weekly: { day: string; slots: { time: string; label: string; place?: string }[] }[] = [
  { day: "Mardi", slots: [
    { time: "12h00", label: "Maîtres", place: "Lamentin" },
    { time: "17h30", label: "Marlin 1 & 2" },
    { time: "18h30", label: "Loisirs" },
    { time: "19h30", label: "Étudiant" },
  ] },
  { day: "Mercredi", slots: [{ time: "19h30", label: "Maîtres" }] },
  { day: "Jeudi", slots: [
    { time: "17h30", label: "Marlin 1" },
    { time: "18h30", label: "Marlin 2" },
    { time: "19h30", label: "Maîtres · Étudiant · Palmes" },
  ] },
  { day: "Vendredi", slots: [{ time: "12h00", label: "Maîtres", place: "Lamentin" }] },
  { day: "Samedi", slots: [
    { time: "12h00", label: "Aquagym" },
    { time: "13h00", label: "Adultes débutants" },
    { time: "14h30", label: "Bleu 1 · Loisirs" },
    { time: "15h00", label: "Blanc 1" },
    { time: "15h15", label: "Jaune 1" },
    { time: "15h45", label: "Blanc 2" },
    { time: "16h00", label: "Jaune 2" },
    { time: "16h45", label: "Bleu 2 · Violet" },
  ] },
];

export const events = [
  { date: "2026-10-18", title: "Course en mer — Défi Didier 113", time: "" },
  { date: "2026-10-24", title: "Challenge Perf 32", time: "15h00–19h00" },
  { date: "2026-10-25", title: "Challenge Perf 32", time: "07h30–13h00" },
  { date: "2026-11-07", title: "Interclubs toutes catégories", time: "15h30–20h00" },
  { date: "2026-11-08", title: "Interclubs toutes catégories", time: "06h30–11h00" },
];

export const documents = [
  { name: "Licence + questionnaire de santé — Mineur 2027", url: "https://app.assoconnect.com/services/storage?type=document&id=7511967&secret=BwZZQQGwo4oqZR5qqXQe300EVLgvGqU2Wa2FTfvQ&timestamp=1785457367&download=1" },
  { name: "Licence + questionnaire de santé — Majeur 2027", url: "https://app.assoconnect.com/services/storage?type=document&id=7511968&secret=tD01tnuGkICkVLsmc5vMEvbpZpg0J7JY2AmAxXOq&timestamp=1785457483&download=1" },
  { name: "Formulaire CAF — Lwazi Jenes", url: "https://app.assoconnect.com/services/storage?type=document&id=7217206&secret=p4thgGc4sNg9BWMMXPyOI0FCMY20ZdSlnTSfapHr&timestamp=1778976443&download=1" },
];

export const partners = [
  { name: "SOMAREC", description: "Référence martiniquaise de la distribution et de l'entretien de pneumatiques depuis 1967, présente sur toute l'île." },
  { name: "CIVIS Martinique — Groupe SEEN", description: "Entretien des espaces publics, nettoiement urbain et espaces verts, avec une mission d'insertion professionnelle." },
];

export const images = {
  history: historyImg.url,
  committee: committeeImg.url,
  dream: dreamImg.url,
  dreamUrl: `${SITE}/collect/description/775923-n-le-reve-americain-soutenez-16-jeunes-nageurs-martiniquais`,
};

export function meta(title: string, description: string) {
  return {
    meta: [
      { title: `${title} — L'ESPADON Fort-de-France` },
      { name: "description", content: description },
      { property: "og:title", content: `${title} — L'ESPADON` },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}

export const slugify = (n: string) => n.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
export const findFormula = (slug: string) => formulas.find((f) => slugify(f.name) === slug);
