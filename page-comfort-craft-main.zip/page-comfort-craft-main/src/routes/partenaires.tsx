import { createFileRoute, Link } from "@tanstack/react-router";
import { meta, partners } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/partenaires")({
  head: () => meta("Nos partenaires", "Les entreprises martiniquaises qui soutiennent le club L'ESPADON."),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero eyebrow="Ils nous soutiennent" title="Nos partenaires" />
      <section className="mx-auto mt-14 grid max-w-6xl gap-6 px-4 md:grid-cols-2">
        {partners.map((p) => (
          <article key={p.name} className="rounded-3xl border border-border bg-card p-8">
            <h2 className="text-2xl font-bold text-primary">{p.name}</h2>
            <p className="mt-3 text-muted-foreground">{p.description}</p>
          </article>
        ))}
        <Link to="/contact" className="rounded-3xl bg-ocean p-8 text-primary-foreground md:col-span-2">
          <h2 className="text-2xl font-bold">Devenir partenaire</h2>
          <p className="mt-2 opacity-85">Associez votre entreprise à un club historique de Martinique. Contactez-nous →</p>
        </Link>
      </section>
    </>
  );
}
