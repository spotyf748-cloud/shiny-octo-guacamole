import { createFileRoute } from "@tanstack/react-router";
import { ExternalLink, Heart } from "lucide-react";
import { club, images, meta } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/dons")({
  head: () => meta("Faire un don", "Soutenez L'ESPADON et la campagne Le Rêve Américain pour 16 jeunes nageurs martiniquais."),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero eyebrow="Soutenir le club" title="Chaque don fait avancer nos nageurs" />
      <section className="mx-auto mt-14 grid max-w-6xl items-center gap-10 px-4 md:grid-cols-2">
        <img src={images.dream} alt="Campagne Le Rêve Américain" loading="lazy" className="w-full rounded-3xl shadow-soft" />
        <div>
          <span className="rounded-full bg-sun px-3 py-1 text-xs font-bold text-sun-foreground">Campagne en cours</span>
          <h2 className="mt-4 text-3xl font-bold">Le Rêve Américain</h2>
          <p className="mt-3 text-lg text-muted-foreground">Soutenez 16 jeunes nageurs martiniquais dans leur projet.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={images.dreamUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground hover:brightness-110">
              <Heart className="h-4 w-4" /> Soutenir la campagne
            </a>
            <a href={club.donate} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 font-semibold hover:bg-secondary">
              Don libre au club <ExternalLink className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
