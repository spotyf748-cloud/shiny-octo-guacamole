import { createFileRoute, Link } from "@tanstack/react-router";
import { images, meta } from "@/lib/club";
import { PageHero, CtaBand } from "@/components/site";

export const Route = createFileRoute("/club")({
  head: () => meta("Le club", "Plus de 50 ans d'engagement dans la natation martiniquaise : histoire et comité directeur de L'ESPADON."),
  component: Page,
});

const stats = [["1969", "Année de création"], ["50+", "Ans d'engagement"], ["3 ans", "Âge minimum"]];

function Page() {
  return (
    <>
      <PageHero eyebrow="Notre histoire" title="Plus de 50 ans de natation martiniquaise" />
      <section className="mx-auto mt-14 grid max-w-6xl items-center gap-10 px-4 md:grid-cols-2">
        <div className="space-y-4 text-lg">
          <p>Le club a été créé en <strong>1969 par Monsieur Georges Vaton</strong>.</p>
          <p className="text-muted-foreground">Depuis, bénévoles, dirigeants, parents et sympathisants œuvrent pour faire grandir et briller L'ESPADON, club incontournable auprès des Foyalais et des Martiniquais.</p>
          <p className="text-muted-foreground">Notre mission : promouvoir le sport, l'excellence, le respect et le dépassement de soi, en compétition comme en loisir.</p>
          <dl className="grid grid-cols-3 gap-3 pt-4">
            {stats.map(([v, l]) => <div key={l} className="rounded-2xl bg-secondary p-4"><dt className="font-display text-2xl font-bold text-primary">{v}</dt><dd className="text-xs text-muted-foreground">{l}</dd></div>)}
          </dl>
        </div>
        <img src={images.history} alt="Histoire du club L'ESPADON" loading="lazy" className="w-full rounded-3xl object-cover shadow-soft" />
      </section>
      <section className="mx-auto mt-20 max-w-6xl px-4">
        <h2 className="text-3xl font-bold">Le comité directeur</h2>
        <p className="mt-2 text-muted-foreground">Les bénévoles qui font vivre le club. Envie de les rejoindre ? <Link to="/inscriptions" className="font-semibold text-primary">Devenez bénévole</Link>.</p>
        <img src={images.committee} alt="Membres du comité directeur" loading="lazy" className="mt-6 w-full rounded-3xl border border-border" />
      </section>
      <CtaBand />
    </>
  );
}
