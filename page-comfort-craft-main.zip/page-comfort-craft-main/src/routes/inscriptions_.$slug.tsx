import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Clock, Download, Lock, CheckCircle2 } from "lucide-react";
import { documents, findFormula, meta } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/inscriptions_/$slug")({
  loader: ({ params }) => {
    const f = findFormula(params.slug);
    if (!f) throw notFound();
    return f;
  },
  head: ({ loaderData }) =>
    loaderData ? meta(loaderData.name, loaderData.description) : meta("Formule", "Formule d'inscription L'ESPADON"),
  component: Page,
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-3xl font-bold">Formule introuvable</h1>
      <Link to="/inscriptions" className="mt-6 inline-block rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground">Voir toutes les formules</Link>
    </div>
  ),
  errorComponent: () => <p className="p-10 text-center">Erreur de chargement.</p>,
});

function Page() {
  const f = Route.useLoaderData();
  const steps = ["Téléchargez et remplissez la licence + questionnaire de santé", "Cliquez sur « Payer et finaliser »", "Joignez le document et réglez en ligne"];
  return (
    <>
      <PageHero eyebrow={f.audience} title={f.name}>{f.description}</PageHero>
      <div className="mx-auto mt-10 grid max-w-6xl gap-8 px-4 md:grid-cols-3">
        <div className="space-y-8 md:col-span-2">
          <Link to="/inscriptions" className="inline-flex items-center gap-2 text-sm font-semibold text-primary"><ArrowLeft className="h-4 w-4" />Toutes les formules</Link>
          {f.schedule && (
            <section>
              <h2 className="text-xl font-bold">Créneaux</h2>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {f.schedule.map((s) => <li key={s} className="flex gap-2 rounded-2xl bg-muted p-3 text-sm"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-accent" />{s}</li>)}
              </ul>
            </section>
          )}
          <section>
            <h2 className="text-xl font-bold">Comment s'inscrire</h2>
            <ol className="mt-3 space-y-2">
              {steps.map((s, i) => <li key={s} className="flex gap-3"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-secondary text-sm font-bold text-secondary-foreground">{i + 1}</span>{s}</li>)}
            </ol>
            <div className="mt-4 grid gap-2">
              {documents.slice(0, 2).map((d) => (
                <a key={d.name} href={d.url} className="flex items-center gap-2 rounded-2xl border border-border p-3 text-sm font-medium hover:border-primary"><Download className="h-4 w-4 text-primary" />{d.name}</a>
              ))}
            </div>
          </section>
        </div>
        <aside className="h-fit rounded-3xl border border-border bg-card p-6 shadow-soft md:sticky md:top-24">
          <h2 className="text-lg font-bold">Tarifs</h2>
          {f.offers ? (
            <dl className="mt-3 divide-y divide-border text-sm">
              {f.offers.map((o) => <div key={o.name} className="flex justify-between gap-3 py-2"><dt>{o.name}</dt><dd className="font-semibold">{o.price}</dd></div>)}
            </dl>
          ) : <p className="mt-2 text-sm text-muted-foreground">Tarif communiqué par le club.</p>}
          <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><CheckCircle2 className="h-4 w-4 text-accent" />Ouverture : {f.opening}</p>
          <a href={f.url} target="_blank" rel="noreferrer" className="mt-5 flex items-center justify-center gap-2 rounded-full bg-sun py-3 font-semibold text-sun-foreground hover:brightness-95">
            <Lock className="h-4 w-4" /> Payer et finaliser
          </a>
          <p className="mt-2 text-center text-xs text-muted-foreground">Paiement sécurisé dans un nouvel onglet.</p>
        </aside>
      </div>
    </>
  );
}
