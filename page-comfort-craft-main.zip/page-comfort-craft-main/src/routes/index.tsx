import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Baby, Trophy, Waves, CalendarDays, FileText, Heart } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { events, meta } from "@/lib/club";
import { CtaBand } from "@/components/site";

export const Route = createFileRoute("/")({
  head: () => meta("Club de natation", "L'ESPADON, club de natation de Fort-de-France depuis 1969 : école de natation dès 3 ans, compétition, loisirs et aquagym."),
  component: Index,
});

const groups = [
  { icon: Baby, title: "École de natation", text: "Dès 3 ans, le samedi après-midi.", to: "/inscriptions" },
  { icon: Trophy, title: "Compétition", text: "Jeunes et Maîtres, le soir dès 17h30.", to: "/inscriptions" },
  { icon: Waves, title: "Loisirs & bien-être", text: "Aquagym, palmes, adultes débutants.", to: "/inscriptions" },
] as const;

const fmt = (d: string) => new Date(d).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });

function Index() {
  const next = events.filter((e) => new Date(e.date) >= new Date(new Date().toDateString())).slice(0, 3);
  return (
    <>
      <section className="relative isolate overflow-hidden">
        <img src={hero} alt="Jeunes nageurs sous l'eau" width={1600} height={912} className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-deep/90 via-deep/60 to-transparent" />
        <div className="mx-auto max-w-6xl px-4 py-28 text-deep-foreground md:py-40">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">Fort-de-France · depuis 1969</p>
          <h1 className="mt-4 max-w-2xl text-5xl font-extrabold leading-[1.05] md:text-7xl">Plonger. Nager. Progresser.</h1>
          <p className="mt-5 max-w-lg text-lg opacity-90">L'instant bleu qui nous rassemble : des cours dès 3 ans, encadrés par des coachs qualifiés.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/inscriptions" className="inline-flex items-center gap-2 rounded-full bg-sun px-6 py-3 font-semibold text-sun-foreground transition hover:brightness-95">
              S'inscrire <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/horaires" className="rounded-full border border-deep-foreground/40 px-6 py-3 font-semibold transition hover:bg-deep-foreground/10">
              Voir les horaires
            </Link>
          </div>
        </div>
      </section>

      <section className="relative z-10 mx-auto -mt-12 grid max-w-6xl gap-4 px-4 md:grid-cols-3">
        {groups.map((g) => (
          <Link key={g.title} to={g.to} className="group rounded-3xl bg-card p-6 shadow-soft transition hover:-translate-y-1">
            <g.icon className="h-8 w-8 text-primary" />
            <h2 className="mt-4 text-xl font-bold">{g.title}</h2>
            <p className="mt-1 text-muted-foreground">{g.text}</p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">Tarifs <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></span>
          </Link>
        ))}
      </section>

      <section className="mx-auto mt-20 grid max-w-6xl gap-8 px-4 md:grid-cols-2">
        <div>
          <h2 className="flex items-center gap-2 text-2xl font-bold"><CalendarDays className="h-6 w-6 text-primary" />Prochains évènements</h2>
          <ul className="mt-5 space-y-3">
            {next.length === 0 && <li className="text-muted-foreground">Aucun évènement programmé pour le moment.</li>}
            {next.map((e) => (
              <li key={e.date + e.title} className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4">
                <span className="w-16 shrink-0 rounded-xl bg-secondary py-2 text-center text-sm font-bold text-secondary-foreground">{fmt(e.date)}</span>
                <span><span className="block font-semibold">{e.title}</span>{e.time && <span className="text-sm text-muted-foreground">{e.time}</span>}</span>
              </li>
            ))}
          </ul>
          <Link to="/evenements" className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">Tout le calendrier <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <div className="grid gap-4">
          <Link to="/documents" className="flex items-start gap-4 rounded-3xl bg-secondary p-6 transition hover:brightness-[0.98]">
            <FileText className="h-7 w-7 shrink-0 text-primary" />
            <span><span className="block text-lg font-bold">Documents d'inscription</span><span className="text-muted-foreground">Licence, questionnaire de santé, formulaire CAF.</span></span>
          </Link>
          <Link to="/dons" className="flex items-start gap-4 rounded-3xl bg-ocean p-6 text-primary-foreground transition hover:brightness-110">
            <Heart className="h-7 w-7 shrink-0 text-sun" />
            <span><span className="block text-lg font-bold">Le Rêve Américain</span><span className="opacity-85">Soutenez 16 jeunes nageurs martiniquais.</span></span>
          </Link>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
