import { createFileRoute, Link } from "@tanstack/react-router";
import { Facebook, Instagram, MapPin, Mail, Baby, Handshake, Info } from "lucide-react";
import { club, meta } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/contact")({
  head: () => meta("Contact", "Contactez L'ESPADON pour une inscription, des informations sur les entraînements ou un partenariat."),
  component: Page,
});

const reasons = [
  { icon: Baby, t: "Inscrire un enfant", to: "/inscriptions" },
  { icon: Info, t: "Horaires d'entraînement", to: "/horaires" },
  { icon: Handshake, t: "Devenir partenaire", to: "/partenaires" },
] as const;

function Page() {
  return (
    <>
      <PageHero eyebrow="Contact" title="Une question ? Écrivez-nous" />
      <section className="mx-auto mt-14 grid max-w-6xl gap-8 px-4 md:grid-cols-2">
        <div>
          <h2 className="text-xl font-bold">Peut-être déjà la réponse ici</h2>
          <div className="mt-4 grid gap-3">
            {reasons.map((r) => (
              <Link key={r.t} to={r.to} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 font-semibold hover:border-primary">
                <r.icon className="h-5 w-5 text-primary" />{r.t}
              </Link>
            ))}
          </div>
        </div>
        <div className="rounded-3xl bg-ocean p-8 text-primary-foreground">
          <Mail className="h-8 w-8 text-sun" />
          <h2 className="mt-3 text-2xl font-bold">Formulaire de contact</h2>
          <p className="mt-2 opacity-85">Vos données servent uniquement à répondre à votre demande et ne sont jamais transmises.</p>
          <a href={club.contactForm} target="_blank" rel="noreferrer" className="mt-6 inline-block rounded-full bg-sun px-6 py-3 font-semibold text-sun-foreground hover:brightness-95">Envoyer un message</a>
          <p className="mt-8 flex gap-2 text-sm opacity-85"><MapPin className="h-4 w-4 shrink-0" />{club.address}</p>
          <div className="mt-4 flex gap-3">
            <a href={club.facebook} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/15 px-4 py-2 text-sm"><Facebook className="h-4 w-4" />Facebook</a>
            <a href={club.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/15 px-4 py-2 text-sm"><Instagram className="h-4 w-4" />Instagram</a>
          </div>
        </div>
      </section>
    </>
  );
}
