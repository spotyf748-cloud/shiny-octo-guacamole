import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText } from "lucide-react";
import { documents, meta } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/documents")({
  head: () => meta("Documents", "Formulaires de licence, questionnaires de santé et formulaire CAF à télécharger."),
  component: Page,
});

function Page() {
  return (
    <>
      <PageHero eyebrow="À télécharger" title="Licences & questionnaires de santé">
        Remplissez le document adapté et joignez-le à votre inscription en ligne.
      </PageHero>
      <ul className="mx-auto mt-14 max-w-3xl space-y-4 px-4">
        {documents.map((d) => (
          <li key={d.name}>
            <a href={d.url} className="flex items-center gap-4 rounded-3xl border border-border bg-card p-5 transition hover:border-primary">
              <FileText className="h-8 w-8 shrink-0 text-primary" />
              <span className="flex-1 font-semibold">{d.name}</span>
              <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-4 py-2 text-sm font-semibold text-secondary-foreground"><Download className="h-4 w-4" />Télécharger</span>
            </a>
          </li>
        ))}
      </ul>
    </>
  );
}
