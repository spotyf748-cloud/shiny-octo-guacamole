import { createFileRoute } from "@tanstack/react-router";
import { events, meta } from "@/lib/club";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/evenements")({
  head: () => meta("Évènements", "Calendrier des compétitions et évènements du club L'ESPADON."),
  component: Page,
});

function Page() {
  const today = new Date(new Date().toDateString());
  return (
    <>
      <PageHero eyebrow="Calendrier" title="Évènements à venir" />
      <ol className="mx-auto mt-14 max-w-3xl space-y-4 px-4">
        {events.map((e) => {
          const d = new Date(e.date);
          const past = d < today;
          return (
            <li key={e.date + e.title} className={`flex items-center gap-5 rounded-3xl border border-border bg-card p-5 ${past ? "opacity-50" : ""}`}>
              <div className="w-20 shrink-0 rounded-2xl bg-ocean py-3 text-center text-primary-foreground">
                <p className="font-display text-2xl font-bold">{d.getDate()}</p>
                <p className="text-xs uppercase">{d.toLocaleDateString("fr-FR", { month: "short" })}</p>
              </div>
              <div>
                <h2 className="text-lg font-bold">{e.title}</h2>
                <p className="text-sm text-muted-foreground">
                  {d.toLocaleDateString("fr-FR", { weekday: "long" })}{e.time && ` · ${e.time}`}{past && " · terminé"}
                </p>
              </div>
            </li>
          );
        })}
      </ol>
    </>
  );
}
